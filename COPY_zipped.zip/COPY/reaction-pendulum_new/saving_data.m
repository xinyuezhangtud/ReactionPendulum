
save('step', 'theta', 'phi_dot', 'i_m', 'u')
