% This script is executed every time that an experiment is initialized

% Define the sampling time here:
h = 0.05;